# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Select by vertex count",
    "author" : "Dead_Sue", 
    "description" : "Addon select object of vertex count",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "Addon Free",
    "doc_url": "https://blenderartists.org/t/select-similar-objects-by-number-of-vertices/1110517/11", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_OT_Select_Vertex_Count_50190(bpy.types.Operator):
    bl_idname = "sna.select_vertex_count_50190"
    bl_label = "Select vertex count"
    bl_description = "Select vertex count"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        active_object = bpy.context.view_layer.objects.active
        active_verts = len(active_object.data.vertices)
        for all_objects in  bpy.context.view_layer.objects:
            if all_objects.type == 'MESH':
                all_objects_verts = len(all_objects.data.vertices)           
                if all_objects_verts == active_verts:
                    all_objects.select_set(state = True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_view3d_mt_select_object_F4EAF(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.select_vertex_count_50190', text='Select by vertex count', icon_value=131, emboss=True, depress=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Select_Vertex_Count_50190)
    bpy.types.VIEW3D_MT_select_object.append(sna_add_to_view3d_mt_select_object_F4EAF)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Select_Vertex_Count_50190)
    bpy.types.VIEW3D_MT_select_object.remove(sna_add_to_view3d_mt_select_object_F4EAF)
